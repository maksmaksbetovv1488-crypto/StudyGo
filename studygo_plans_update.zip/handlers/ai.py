"""AI features with plan limits."""

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from keyboards import main_menu_kb, back_kb
from states import AIStates
from ai_service import call_gemini
from handlers.start import safe_edit
from plans import has_feature, BIO_TAG, plan_title
from database import (
    is_blocked, ensure_user, get_active_plan, try_consume_request, log_ai_usage,
)

router = Router()


async def check_bio(bot: Bot, user_id: int) -> bool:
    try:
        chat = await bot.get_chat(user_id)
        bio = (getattr(chat, "bio", None) or "") + " "
        about = getattr(chat, "description", None) or ""
        return BIO_TAG.lower() in (bio + about).lower()
    except Exception:
        return False


async def gate(user_id: int, feature: str, bot=None) -> tuple[bool, str]:
    if is_blocked(user_id):
        return False, "🚫 Заблокированы."
    plan = get_active_plan(user_id)
    if not has_feature(plan, feature):
        return False, (
            f"🔒 Функция недоступна на тарифе <b>{plan_title(plan)}</b>.\n"
            f"Открой 💎 Подписка — Free+ / Pro / Pro+ / Ultra."
        )
    has_bio = False
    if bot:
        has_bio = await check_bio(bot, user_id)
    ok, err = try_consume_request(user_id, has_bio=has_bio)
    if not ok:
        return False, err
    return True, ""


async def run_ai(message: Message, prompt: str, req_type: str, bot: Bot, image_bytes=None):
    await message.answer("⏳ Думаю...")
    answer = await call_gemini(prompt, image_bytes=image_bytes)
    log_ai_usage(message.from_user.id, req_type, success=True)
    await message.answer(answer, reply_markup=main_menu_kb())


@router.callback_query(F.data == "ai_helper")
async def cb_ai_helper(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AIStates.waiting_question)
    await safe_edit(
        callback.message,
        "🧠 <b>AI-помощник</b>\n\nНапиши вопрос или задачу.",
        reply_markup=back_kb(),
    )
    await callback.answer()


@router.message(AIStates.waiting_question)
async def process_q(message: Message, state: FSMContext, bot: Bot):
    ok, err = await gate(message.from_user.id, "text", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        await state.clear()
        return
    await run_ai(message, message.text, "text", bot)
    await state.clear()


@router.callback_query(F.data == "ai_photo")
async def cb_photo(callback: CallbackQuery, state: FSMContext, bot: Bot):
    plan = get_active_plan(callback.from_user.id)
    if not has_feature(plan, "photo"):
        await callback.answer("Нужен Free+ или выше.", show_alert=True)
        return
    await state.set_state(AIStates.waiting_photo)
    await safe_edit(callback.message, "📸 Пришли фото задания.", reply_markup=back_kb())
    await callback.answer()


@router.message(AIStates.waiting_photo, F.photo)
async def process_photo(message: Message, state: FSMContext, bot: Bot):
    ok, err = await gate(message.from_user.id, "photo", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        await state.clear()
        return
    photo = message.photo[-1]
    file = await bot.get_file(photo.file_id)
    data = await bot.download_file(file.file_path)
    await run_ai(
        message,
        "Распознай задание на фото и реши. Если несколько — пронумеруй.",
        "photo",
        bot,
        image_bytes=data.read(),
    )
    await state.clear()


@router.message(AIStates.waiting_photo)
async def process_photo_bad(message: Message):
    await message.answer("Нужно именно фото.")


@router.callback_query(F.data == "ai_explain")
async def cb_explain(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AIStates.waiting_topic)
    await safe_edit(callback.message, "📚 Напиши тему для объяснения.", reply_markup=back_kb())
    await callback.answer()


@router.message(AIStates.waiting_topic)
async def process_topic(message: Message, state: FSMContext, bot: Bot):
    ok, err = await gate(message.from_user.id, "explain", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        await state.clear()
        return
    prompt = (
        f"Объясни школьнику тему: {message.text}\n"
        "Структура: простыми словами, главное, пример, ошибки, проверь себя."
    )
    await run_ai(message, prompt, "explain", bot)
    await state.clear()


@router.callback_query(F.data == "ai_test")
async def cb_test(callback: CallbackQuery, state: FSMContext, bot: Bot):
    plan = get_active_plan(callback.from_user.id)
    if not has_feature(plan, "test"):
        await callback.answer("Нужен тариф Pro или выше.", show_alert=True)
        return
    await state.set_state(AIStates.waiting_test_params)
    await safe_edit(
        callback.message,
        "📝 Формат: <code>предмет | тема | класс | число | сложность</code>",
        reply_markup=back_kb(),
    )
    await callback.answer()


@router.message(AIStates.waiting_test_params)
async def process_test(message: Message, state: FSMContext, bot: Bot):
    ok, err = await gate(message.from_user.id, "test", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        await state.clear()
        return
    prompt = f"Создай школьный тест: {message.text}. Варианты A B C D, в конце ответы."
    await run_ai(message, prompt, "test", bot)
    await state.clear()


@router.callback_query(F.data == "ai_check")
async def cb_check(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AIStates.waiting_check_answer)
    await safe_edit(callback.message, "✅ Пришли условие и свой ответ.", reply_markup=back_kb())
    await callback.answer()


@router.message(AIStates.waiting_check_answer)
async def process_check(message: Message, state: FSMContext, bot: Bot):
    ok, err = await gate(message.from_user.id, "check", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        await state.clear()
        return
    prompt = f"Проверь ответ ученика:\n{message.text}\nУкажи верно ли, ошибку, правильное решение."
    await run_ai(message, prompt, "check", bot)
    await state.clear()


@router.callback_query(F.data == "ai_conspect")
async def cb_conspect(callback: CallbackQuery, state: FSMContext, bot: Bot):
    plan = get_active_plan(callback.from_user.id)
    if not has_feature(plan, "conspect"):
        await callback.answer("Нужен Free+ или выше.", show_alert=True)
        return
    await state.set_state(AIStates.waiting_conspect)
    await safe_edit(callback.message, "📖 Тема для короткого конспекта:", reply_markup=back_kb())
    await callback.answer()


@router.message(AIStates.waiting_conspect)
async def process_conspect(message: Message, state: FSMContext, bot: Bot):
    ok, err = await gate(message.from_user.id, "conspect", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        await state.clear()
        return
    prompt = f"Краткий конспект (1 экран) для школьника по теме: {message.text}"
    await run_ai(message, prompt, "conspect", bot)
    await state.clear()


@router.callback_query(F.data == "ai_error")
async def cb_error(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not has_feature(get_active_plan(callback.from_user.id), "error_review"):
        await callback.answer("Нужен Pro или выше.", show_alert=True)
        return
    await state.set_state(AIStates.waiting_error)
    await safe_edit(callback.message, "🔎 Пришли задачу и неверный ответ — разберём ошибку.", reply_markup=back_kb())
    await callback.answer()


@router.message(AIStates.waiting_error)
async def process_error(message: Message, state: FSMContext, bot: Bot):
    ok, err = await gate(message.from_user.id, "error_review", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        await state.clear()
        return
    prompt = f"Разбор ошибки ученика. Почему неверно и как правильно:\n{message.text}"
    await run_ai(message, prompt, "error_review", bot)
    await state.clear()


@router.callback_query(F.data == "ai_week")
async def cb_week(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not has_feature(get_active_plan(callback.from_user.id), "week_plan"):
        await callback.answer("Нужен Pro+ или выше.", show_alert=True)
        return
    await state.set_state(AIStates.waiting_week)
    await safe_edit(callback.message, "📅 Предмет и цель на неделю:", reply_markup=back_kb())
    await callback.answer()


@router.message(AIStates.waiting_week)
async def process_week(message: Message, state: FSMContext, bot: Bot):
    ok, err = await gate(message.from_user.id, "week_plan", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        await state.clear()
        return
    prompt = f"План учёбы на 7 дней для школьника:\n{message.text}"
    await run_ai(message, prompt, "week_plan", bot)
    await state.clear()


@router.message(F.text)
async def fallback_text(message: Message, state: FSMContext, bot: Bot):
    if not message.text or message.text.startswith("/"):
        return
    if await state.get_state():
        return
    ensure_user(message.from_user.id, message.from_user.username, message.from_user.first_name)
    ok, err = await gate(message.from_user.id, "text", bot)
    if not ok:
        await message.answer(err, reply_markup=main_menu_kb())
        return
    await run_ai(message, message.text, "text", bot)
